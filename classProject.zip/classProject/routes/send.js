
var express = require('express');
var router = express.Router();
var nodemailer = require('nodemailer');
var ssn;
router.post('/', function (req, res, next) {
    ssn = req.session;
    var fullname = req.body.fullname;
    var subject = req.body.subject;
    var message = req.body.message;
    var transporter = nodemailer.createTransport({
        host: 'smtp.gmail.com',
        port: 465,
        secure: true,
        service: 'gmail',
        auth: {
            user: 'test.razmgir@gmail.com',
            pass: 'Admin111$'
        }
    });
    var mailOptions = {
        from: 'test.razmgir@gmail.com',
        to: 'razmgir.rahim@gmail.com',
        subject: 'Message from ' + fullname,
        text: 'Subject: ' + subject + '\nThe message: ' + message
    };
    transporter.sendMail(mailOptions, function (error, info) {
        if (error) {
            console.log(error);
        } else {
            console.log('Email sent: ' + info.response);
        }
    });
    //res.render('send', { title: 'Success', fn: fullname, su: subject, me: message });
    ssn.message = "Your message was sent successfully!"
    res.redirect('contact');
});

//router.get('/', function (req, res, next) {
//    res.redirect('contact');
//});

module.exports = router;