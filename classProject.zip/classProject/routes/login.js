var express = require('express');
var router = express.Router();
var ssn;

router.get('/', function (req, res, next) {
    ssn = req.session;
    res.render('login', {error: ssn.error});
});



router.post('/', function (req, res, next) {
    ssn = req.session;
    var email = req.body.email;
    var pass = req.body.user_password;
    var MongoClient = require('mongodb').MongoClient;
    var url = "mongodb+srv://Expressty:ExpresstyPassword@expressty-z0jtc.azure.mongodb.net/test?retryWrites=true&w=majority";
    MongoClient.connect(url, function (err, db) {
        if (err) throw err;
        var dbo = db.db("firsty");
        dbo.collection('users').findOne({ email: email, pass: pass }, function (err, docs) {
        if (docs == null) {
            ssn.error = "Email or password is wrong. Please try again.";
            res.redirect("login");
        } else {
            ssn.fname = docs.fname;
            ssn.lname = docs.lname;
            ssn.email = docs.email;
            ssn.dpos = docs.pos;
            ssn.dneg = docs.neg;
            ssn.dneu = docs.neu;
            res.redirect("profile");
        }
        db.close();
        });
    });
});
module.exports = router;
