var express = require('express');
var router = express.Router();
var ssn;
var city, temp, w;
router.post('/', function (req, res, next) {
    ///reading location cookies that were stored by the javascripts/js.js
    console.log(req.cookies);
    ssn = req.session;
    ssn.lat = req.cookies.lat;
    ssn.long = req.cookies.long;
    ///
    ssn.fname = req.body.first_name;
    ssn.lname = req.body.last_name;
    ssn.email = req.body.email;
    ssn.pass = req.body.user_password;
    /// Insert new user in db
    var MongoClient = require('mongodb').MongoClient;
    var url = "mongodb+srv://Expressty:ExpresstyPassword@expressty-z0jtc.azure.mongodb.net/test?retryWrites=true&w=majority";
    MongoClient.connect(url, function (err, db) {
        if (err) throw err;
        var dbo = db.db("firsty");
        var myobj = { fname: ssn.fname, lname: ssn.lname, email: ssn.email, pass: ssn.pass, pos: 0, neg: 0, neu: 0 };
        dbo.collection("users").insertOne(myobj, function (err, res) {
            if (err) throw err;
            console.log("1 document inserted");
            db.close();
        });
    });
    /// first values for new users comment activity
    ssn.dpos = 0;
    ssn.dneg = 0;
    ssn.dneu = 0;
    //// weather API
    var unirest = require("unirest");
    var api = unirest("GET", "https://community-open-weather-map.p.rapidapi.com/weather");
    api.query({
        "lat": ssn.lat,
        "lon": ssn.long,
        "units": "%22metric%22",
    });

    api.headers({
        "x-rapidapi-host": "community-open-weather-map.p.rapidapi.com",
        "x-rapidapi-key": "1adc0d87bdmsh49f4016caba6f17p19369fjsn02660f49201f"
    });
    api.end(function (res) {
        if (res.error) throw new Error(res.error);
        console.log(res.body.weather.main);
        console.log(res.body.main.feels_like);
        city = res.body.name;
        temp = res.body.main.feels_like - 273.15;
        w = res.body.weather[0].main;
    });
    //// Need timeout to receive values from api before redirecting
    setTimeout(function () {
        res.render('profile', { fn: ssn.fname, ln: ssn.lname, em: ssn.email, result: ssn.result, pos: ssn.pos, neg: ssn.neg, neu: ssn.neu, input: ssn.input, dpos: ssn.dpos, dneg: ssn.dneg, dneu: ssn.dneu, city: city, temp: temp, w: w });
    }, 300);
});

router.get('/', function (req, res, next) {
    ///reading location cookies that were stored by the javascripts/js.js
    console.log(req.cookies.lat);
    ssn = req.session;
    ssn.lat = req.cookies.lat;
    ssn.long = req.cookies.long;
    if (ssn.email) {
        //// weather API
        var unirest = require("unirest");
        var api = unirest("GET", "https://community-open-weather-map.p.rapidapi.com/weather");
        api.query({
            "lat": ssn.lat,
            "lon": ssn.long,
            "units": "%22metric%22",
        });
        api.headers({
            "x-rapidapi-host": "community-open-weather-map.p.rapidapi.com",
            "x-rapidapi-key": "1adc0d87bdmsh49f4016caba6f17p19369fjsn02660f49201f"
        });
        api.end(function (res) {
            if (res.error) throw new Error(res.error);
            console.log(res.body.name);
            console.log(res.body.main.feels_like);
            city = res.body.name;
            temp = Math.floor(res.body.main.feels_like - 273.15);
            console.log(res.body.weather[0].main)
            w = res.body.weather[0].main;
        });
        ////Need timeout to receive values from api before redirecting
        setTimeout(function () {
            res.render('profile', { fn: ssn.fname, ln: ssn.lname, em: ssn.email, result: ssn.result, pos: ssn.pos, neg: ssn.neg, neu: ssn.neu, input: ssn.input, dpos: ssn.dpos, dneg: ssn.dneg, dneu: ssn.dneu, city: city, temp: temp, w: w });
        }, 300);
    }
    else {
        ssn.error = "You need to log in first!";
        res.redirect('login');
    }
});

module.exports = router;