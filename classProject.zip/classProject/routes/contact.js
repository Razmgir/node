var express = require('express');
var router = express.Router();
var ssn;
router.get('/', function (req, res, next) {
    ssn = req.session;
    res.render('contact', { title: "Contact", msg: ssn.message });
});

module.exports = router;