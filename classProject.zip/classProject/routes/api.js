var express = require('express');
var router = express.Router();
var ssn;
var result, pos, neg, neu, ginput;
router.post('/', function (req, res, next) {
    ssn = req.session;
    var input = req.body.comment;
    var unirest = require("unirest");
    var api = unirest("POST", "https://japerk-text-processing.p.rapidapi.com/sentiment/");
    api.headers({
        "x-rapidapi-host": "japerk-text-processing.p.rapidapi.com",
        "x-rapidapi-key": "1adc0d87bdmsh49f4016caba6f17p19369fjsn02660f49201f",
        "content-type": "application/x-www-form-urlencoded"
    });
    api.form({
        "language": "english",
        "text": input
    });
    api.end(function (res) {
        //if (res.error) throw new Error(res.error);
        console.log(res.body);
        result = res.body.label;
        pos = res.body.probability.pos;
        neg = res.body.probability.neg;
        neu = res.body.probability.neutral;
        ginput = input;
    });
    setTimeout(function () {
        if (result) {
            
            switch (result) {
                case 'pos':
                    result += 'itive';
                    ssn.dpos += 1;
                    break;
                case 'neg':
                    result += 'ative';
                    ssn.dneg += 1;
                    break;
                case 'neutral':
                    ssn.dneu += 1;
                    break;
            }
            ssn.result = result;
            ssn.pos = Math.floor(pos * 100);
            ssn.neg = Math.floor(neg * 100);
            ssn.neu = Math.floor(neu * 100);
            ssn.input = ginput;
            console.log(ssn.result);
            ////
            var MongoClient = require('mongodb').MongoClient;
            var url = "mongodb+srv://Expressty:ExpresstyPassword@expressty-z0jtc.azure.mongodb.net/test?retryWrites=true&w=majority";
            MongoClient.connect(url, function (err, db) {
                if (err) throw err;
                var dbo = db.db("firsty");
                var myquery = { email: ssn.email };
                var newvalues = { $set: { pos: ssn.dpos , neg: ssn.dneg, neu: ssn.dneu } };
                dbo.collection("users").updateOne(myquery, newvalues, function (err, res) {
                    if (err) throw err;
                    console.log("document updated");
                    db.close();
                });
            });
            ////
            res.redirect('profile');
        }
    }, 500); 
});

module.exports = router;